package MVC;

import java.util.HashMap;
import java.util.Map;

public class ModelAndView {
	private String ViewName;
	private Map<String,String> requestMap = new HashMap<String,String>();
	private Map<String,String> responseMap = new HashMap<String,String>();
	public void setViewName(String vname) {
		ViewName = vname;
	}
	public String getViewName(){
		return ViewName;
	}

	public String getMap(String key) {
		return requestMap.get(key);
	}
	public void putMap(String key, String value){
		requestMap.put(key, value);
	}
	public void addObject(String key, String value) {
		responseMap.put(key, value);
	}
	public  Map<String,String> getResponseMap(){
		return this.responseMap;
	}
}
