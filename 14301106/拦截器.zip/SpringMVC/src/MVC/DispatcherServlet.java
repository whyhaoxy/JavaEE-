package MVC;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Annotation.RequestMapping;

import resource.LocalFileResource;
import test.test;
import factory.BeanFactory;
import factory.XMLBeanFactory;

public class DispatcherServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public DispatcherServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String action=request.getServletPath();	// /hello
		System.out.println(action);
		
		//将request中的消息写入到ModelAndView
		ModelAndView mav=new ModelAndView();
		Enumeration<?> enu=request.getParameterNames();
		while(enu.hasMoreElements()){
			String name=(String)enu.nextElement();
			String value=request.getParameter(name);
			mav.putMap(name, value);
		}
		String classpath = this.getClass().getResource("/").getPath().replaceFirst("/", "");
		System.out.println(classpath);
		String webappRoot = classpath.replaceAll("classes/", "");
		String path=webappRoot+"beans.xml";
		System.out.println(path);
		//得到test 利用ioc机制
		LocalFileResource resource = new LocalFileResource(path);
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		test test=(test) beanFactory.getBean("test");
		
		Class<?> testClass=test.getClass();
		String url=null;
		Method[] methods=testClass.getMethods(); 
		for(Method method:methods){
			RequestMapping RM = method.getAnnotation(RequestMapping.class);
			String valueMethod = RM.value(); //   /hello		
			if(valueMethod.equals(action)){
				try {
					ModelAndView model=(ModelAndView) method.invoke(testClass.newInstance(), mav);
					 url=model.getViewName();
					List<String> list=new ArrayList<String>(model.getResponseMap().keySet());
					for(String keySet:list){
						request.setAttribute(keySet, model.getResponseMap().get(keySet));
					}
					break;
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		request.getRequestDispatcher(url+".jsp").forward(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		this.doGet(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
