package Annotation;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
public @interface Controller {

}
